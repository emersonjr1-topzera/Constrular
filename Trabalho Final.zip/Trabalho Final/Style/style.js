console.log("script.js carregado!");

document.addEventListener("DOMContentLoaded", function () {
    // ----- CARROSSEL -----
    const carrosselLista = document.querySelector(".carrossel-lista");
    const btnEsquerda = document.querySelector(".carrossel-btn-esquerda");
    const btnDireita = document.querySelector(".carrossel-btn-direita");

    if (carrosselLista && btnEsquerda && btnDireita) {
        const scrollAmount = 260;

        btnDireita.addEventListener("click", () => {
            carrosselLista.scrollBy({
                left: scrollAmount,
                behavior: "smooth"
            });
        });

        btnEsquerda.addEventListener("click", () => {
            carrosselLista.scrollBy({
                left: -scrollAmount,
                behavior: "smooth"
            });
        });
    }

    // -----popup da imagem -----
    const imagensCarrossel = document.querySelectorAll(".carrossel-item img");
    const lightbox = document.getElementById("lightbox");
    const lightboxImg = document.getElementById("lightbox-img");
    const btnFechar = document.querySelector(".lightbox-fechar");

    if (imagensCarrossel.length > 0 && lightbox && lightboxImg && btnFechar) {
        imagensCarrossel.forEach(img => {
            img.style.cursor = "pointer";

            img.addEventListener("click", () => {
                const src = img.getAttribute("src");
                const alt = img.getAttribute("alt") || "Obra ampliada";

                lightboxImg.setAttribute("src", src);
                lightboxImg.setAttribute("alt", alt);

                lightbox.classList.add("aberto");
            });
        });

        btnFechar.addEventListener("click", () => {
            lightbox.classList.remove("aberto");
        });

        lightbox.addEventListener("click", (evento) => {
            if (evento.target === lightbox) {
                lightbox.classList.remove("aberto");
            }
        });

        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                lightbox.classList.remove("aberto");
            }
        });
    }

    // ----- FORMULÁRIO DE CONTATO (mensagem de sucesso)-----
    const formContato = document.querySelector(".form-contato");

    if (formContato) {
        formContato.addEventListener("submit", function (evento) {
            evento.preventDefault(); // impede o envio tradicional

            alert("Sua mensagem foi enviada com sucesso! Em breve entraremos em contato.");

            formContato.reset();
        });
    }
});
